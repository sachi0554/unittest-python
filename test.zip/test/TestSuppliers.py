

import os
from unittest import TestCase, mock
import argparse
from datetime import datetime
import tempfile
import shutil
from urllib import response

import Suppliers
from Create_Web_Service_Support import Create_Web_Service_Support 
from Update_Web_Service_Support import Update_Web_Service_Support 
from FRMS_Support import FRMS_Support
from CaptureFileSupport import CaptureFileSupport
from FailFileSupport import FailFileSupport
  


class TestSuppliers(TestCase):
    root_directory = tempfile.mkdtemp()
    ini_file=None
    section_name=''
    notification_file=os.path.join(root_directory, 'test_suppliers.xlsx')
    failure_notification_file=os.path.join(root_directory, 'test_failures.xlsx')


    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)

        

    #test case for read_commandline_args with param
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_process_local_variables(self, args):

        return_val= Suppliers.read_commandline_args()

        self.assertEqual(return_val.ini_file, None)
        self.assertEqual(return_val.section_name, '')
        self.assertEqual(return_val.notificationFile, self.notification_file)
        self.assertEqual(return_val.failureNotificationFile, self.failure_notification_file)

    
    #test case end
    

    #test case for test config json file key

    def test_config_file(self):
        json_config = Suppliers.read_config()

        self.assertGreater(len(json_config), 0)

        self.assertTrue("Oracle_section_name" in json_config)
        self.assertTrue("FRMS_section_name" in json_config)
        self.assertTrue("FRMS_Mode" in json_config)
        self.assertTrue("Oracle_WSDL" in json_config)
        self.assertTrue("Oracle_user" in json_config)
        self.assertTrue("Oracle_password" in json_config)
        self.assertTrue("sender_email" in json_config)
        self.assertTrue("recipient_email" in json_config)
        self.assertTrue("CC_email" in json_config)

    
    #test case end

    
    
    #test case connection failed 

    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_workflow_with_connection_failed(self,args, mock_conn):
        
        mock_conn.return_value= -1, '', ''

        with self.assertRaises(SystemExit) as sye:
            Suppliers.main()

        self.assertEqual(sye.exception.code , -1)
    
    #test case end 

    
    #test case workflow for scanForCreateRecord 

    @mock.patch.object(FRMS_Support, 'scan_for_update_record')
    @mock.patch.object(CaptureFileSupport, 'capture_create_event')
    @mock.patch.object(FRMS_Support, 'reset_create_flag')
    @mock.patch.object(Create_Web_Service_Support, 'send_message')
    @mock.patch.object(FRMS_Support, 'scan_for_create_record')
    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_workflow_for_scan_for_create_records(self,args, mock_conn, mock_scan_for_create_record, mock_send_message, mock_reset_create_flag, mock_capture_event, mock_scan_for_update_record):
        result=[(56666111118888886, 'Completed', '61568', 'dddfaf36-c8f7-413d-9e7d-ef138c9be89e', 'N/A', '75206', '83-2822552', 'US_Dollar', 'Dallas', 'US', None, datetime(2022, 3, 25, 16, 0, 46, 304000), '5134 Miller Ave', '', 'MeD Consultings, LLC', 'TX', 'US', 'CHECK', 'USD', True, False, True, 'MeD Consultings, LLC', None, False, 'SPEND_AUTHORIZED', True, 'NA', True, 'N/A', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'EIN', '61568', 'NA', 'SEG Worldwide', 'N/A', True, 'medco1231231231@gmail.com', 'NA', 'US Mendix Consultant', 'NA', 'NA', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        conn= mock.Mock()

        mock_conn.return_value= 0, conn, conn
        mock_scan_for_create_record.return_value = result
        mock_scan_for_update_record.return_value= []
        mock_send_message.return_value= "Success", ''
        
        Suppliers.main()

        self.assertEqual(mock_reset_create_flag.call_count , 1)
        self.assertEqual(mock_capture_event.call_count , 1)
    
    #test case end



    #test case workflow for scanForCreateRecord failed response  

    @mock.patch.object(FRMS_Support, 'scan_for_update_record')
    @mock.patch.object(FRMS_Support, 'reset_create_flag')
    @mock.patch.object(FRMS_Support, 'set_unresolved_error_flag')
    @mock.patch.object(FailFileSupport, 'fail_create_event')
    @mock.patch.object(Create_Web_Service_Support, 'send_message')
    @mock.patch.object(FRMS_Support, 'scan_for_create_record')
    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_workflow_for_scan_for_create_records_fail(self,args, mock_conn, 
        mock_scan_for_create_record, 
        mock_send_message, mock_fail_create_event, mock_set_unresolved_error_flag, mock_reset_create_flag, mock_scan_for_update_record):
        result=[(56666111118888886, 'Completed', '61568', 'dddfaf36-c8f7-413d-9e7d-ef138c9be89e', 'N/A', '75206', '83-2822552', 'US_Dollar', 'Dallas', 'US', None, datetime(2022, 3, 25, 16, 0, 46, 304000), '5134 Miller Ave', '', 'MeD Consultings, LLC', 'TX', 'US', 'CHECK', 'USD', True, False, True, 'MeD Consultings, LLC', None, False, 'SPEND_AUTHORIZED', True, 'NA', True, 'N/A', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'EIN', '61568', 'NA', 'SEG Worldwide', 'N/A', True, 'medco1231231231@gmail.com', 'NA', 'US Mendix Consultant', 'NA', 'NA', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        conn= mock.Mock()

        mock_xml_error= '''<Rejection>
                    <Rejection>validation/internal</Rejection>
                    <Rejection>Internal error occurred. Please retry...</Rejection>
                    <Rejection>sc</Rejection>
                    </Rejection>
                    '''

        mock_conn.return_value= 0, conn, conn
        mock_scan_for_create_record.return_value = result
        mock_scan_for_update_record.return_value= []
        mock_send_message.return_value= "error", mock_xml_error
        
        Suppliers.main()

        self.assertEqual(mock_fail_create_event.call_count , 1)
        self.assertEqual(mock_reset_create_flag.call_count , 1)
        self.assertEqual(mock_set_unresolved_error_flag.call_count , 1)
    
    #test case end



    #test case workflow for scanForUpdateRecord with Supplier Number None

    @mock.patch.object(FailFileSupport, 'fail_update_event')
    @mock.patch.object(FRMS_Support, 'reset_update_flag') 
    @mock.patch.object(FRMS_Support, 'set_unresolved_error_flag') 
    @mock.patch.object(FRMS_Support, 'get_supplier_name')
    @mock.patch.object(FRMS_Support, 'get_taxpayer_id')
    @mock.patch.object(FRMS_Support, 'get_supplier_number')
    @mock.patch.object(FRMS_Support, 'scan_for_update_record')
    @mock.patch.object(FRMS_Support, 'scan_for_create_record')
    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                 subject="test subject"))
    def test_workflow_for_scan_for_update_records_with_supplier_number_none(self,args, mock_conn, mock_scan_for_create_record, mock_scan_for_update_record, 
        mock_get_supplier_no, mock_get_taxpayer_id, 
        mock_get_spplier_name, mock_set_unresolved_error_flag, 
        mock_rest_update_flag, mock_fail_update_event):


        result=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        conn= mock.Mock()

        mock_conn.return_value= 0, conn, conn
        mock_scan_for_update_record.return_value= result
        mock_get_supplier_no.return_value = []
        mock_scan_for_create_record.return_value = []
        mock_get_taxpayer_id.return_Value=[('83-2822552'),('83-2822557')]
        mock_get_spplier_name.return_value = [("Test 1"), ("Test2")]
        

        
        Suppliers.main()

        self.assertEqual(mock_set_unresolved_error_flag.call_count , 1)
        self.assertEqual(mock_rest_update_flag.call_count , 1)
        self.assertEqual(mock_fail_update_event.call_count , 1)

    #test case end

    # test case workflow for scanForUpdateRecord with sendMessage

    @mock.patch.object(CaptureFileSupport, 'capture_update_event')
    @mock.patch.object(FRMS_Support, 'reset_unresolved_error_flag') 
    @mock.patch.object(FRMS_Support, 'reset_update_flag') 
    @mock.patch.object(Update_Web_Service_Support, 'send_message')
    @mock.patch.object(FRMS_Support, 'get_supplier_name')
    @mock.patch.object(FRMS_Support, 'get_taxpayer_id')
    @mock.patch.object(FRMS_Support, 'get_supplier_number')
    @mock.patch.object(FRMS_Support, 'scan_for_update_record')
    @mock.patch.object(FRMS_Support, 'scan_for_create_record')
    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_workflow_for_scan_for_update_records_with_send_message(self,args, mock_conn, mock_scan_for_create_record, mock_scan_for_update_record, 
        mock_get_supplier_no, mock_get_taxpayer_id, 
        mock_get_spplier_name, mock_send_message, mock_reset_update_flag, mock_reset_resolved_event, mock_capture_update_event):


        result=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]

        conn= mock.Mock()

        mock_conn.return_value= 0, conn, conn
        mock_scan_for_update_record.return_value= result
        mock_get_supplier_no.return_value = [("10328"),("10333")]
        mock_scan_for_create_record.return_value = []
        mock_get_taxpayer_id.return_Value=[('83-2822552'),('83-2822557')]
        mock_get_spplier_name.return_value = [("Test 1"), ("Test2")]
        mock_send_message.return_value= "Success", ''
        

        
        Suppliers.main()

        self.assertEqual(mock_reset_update_flag.call_count , 1)
        self.assertEqual(mock_reset_resolved_event.call_count , 1)
        self.assertEqual(mock_capture_update_event.call_count , 1)

    #test case end

    #test case workflow for scanForUpdateRecord with notify

    @mock.patch.object(FailFileSupport, 'alt_fail_update_event') 
    @mock.patch.object(FRMS_Support, 'reset_update_flag') 
    @mock.patch.object(FRMS_Support, 'set_unresolved_error_flag') 
    @mock.patch.object(Update_Web_Service_Support, 'notify')
    @mock.patch.object(Update_Web_Service_Support, 'send_message')
    @mock.patch.object(FRMS_Support, 'get_supplier_name')
    @mock.patch.object(FRMS_Support, 'get_taxpayer_id')
    @mock.patch.object(FRMS_Support, 'get_supplier_number')
    @mock.patch.object(FRMS_Support, 'scan_for_update_record')
    @mock.patch.object(FRMS_Support, 'scan_for_create_record')
    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_workflow_for_scan_for_update_records_with_notify(self,args, mock_conn, 
        mock_scan_for_create_record, mock_scan_for_update_record, 
        mock_get_supplier_no, mock_get_taxpayer_id, 
        mock_get_spplier_name, mock_send_message, mock_notify,
        mock_set_unresolved_error_flag, 
        mock_reset_update_flag, mock_alt_update_event):


        result=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]

        conn= mock.Mock()

        

        mock_conn.return_value= 0, conn, conn
        mock_scan_for_update_record.return_value= result
        mock_get_supplier_no.return_value = [("10328"),("10333")]
        mock_scan_for_create_record.return_value = []
        mock_get_taxpayer_id.return_value = [('83-2822552'),('83-2822557')]
        mock_get_spplier_name.return_value = [("Test 1"), ("Test2")]
        mock_send_message.return_value= "Notify", ''
        

        
        Suppliers.main()

        self.assertEqual(mock_notify.call_count , 1)
        self.assertEqual(mock_set_unresolved_error_flag.call_count , 1)
        self.assertEqual(mock_reset_update_flag.call_count , 1)
        self.assertEqual(mock_alt_update_event.call_count , 1)

    #test case end 



    #test case workflow for scanForUpdateRecord with fail

 
    @mock.patch.object(FRMS_Support, 'reset_update_flag') 
    @mock.patch.object(FRMS_Support, 'set_unresolved_error_flag') 
    @mock.patch.object(FailFileSupport, 'fail_update_event')
    @mock.patch.object(Update_Web_Service_Support, 'send_message')
    @mock.patch.object(FRMS_Support, 'get_supplier_name')
    @mock.patch.object(FRMS_Support, 'get_taxpayer_id')
    @mock.patch.object(FRMS_Support, 'get_supplier_number')
    @mock.patch.object(FRMS_Support, 'scan_for_update_record')
    @mock.patch.object(FRMS_Support, 'scan_for_create_record')
    @mock.patch('Suppliers.get_db_connections')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                ini_file=None,
                section_name=section_name, 
                log_level="INFO",
                notificationFile=notification_file,
                failureNotificationFile=failure_notification_file,
                subject="test subject"))
    def test_workflow_for_scan_for_update_records_with_fail(self,args, mock_conn, mock_scan_for_create_record, mock_scan_for_update_record, 
        mock_get_supplier_no, mock_get_taxpayer_id, 
        mock_get_spplier_name, mock_send_message, mock_fail_update_event, mock_set_unresolved_error_flag, mock_reset_update_flag):


        result=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]

        conn= mock.Mock()
        mock_xml_error= '''<Rejection>
                    <Rejection>validation/internal</Rejection>
                    <Rejection>Internal error occurred. Please retry...</Rejection>
                    <Rejection>sc</Rejection>
                    </Rejection>
                    '''

        mock_conn.return_value= 0, conn, conn
        mock_scan_for_update_record.return_value= result
        mock_get_supplier_no.return_value = [("10328"),("10333")]
        mock_scan_for_create_record.return_value = []
        mock_get_taxpayer_id.return_Value=[('83-2822552'),('83-2822557')]
        mock_get_spplier_name.return_value = [("Test 1"), ("Test2")]
        mock_send_message.return_value= "Error", mock_xml_error
        

        
        Suppliers.main()

        self.assertEqual(mock_fail_update_event.call_count , 1)
        self.assertEqual(mock_set_unresolved_error_flag.call_count , 1)
        self.assertEqual(mock_reset_update_flag.call_count , 1)
         

    #test case end 


    #test case for get_supplier_number method 

    def test_get_supplier_number(self):

        expected = [(10328),(10333)]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all") 
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor
       
        f = FRMS_Support("testing", mock_connection, mock_connection)  
        res = f.get_supplier_number(56666111118888886)
        
        self.assertEqual(res, expected)

    #test case end

    #test case for Create_Web_Service_Support testing sendMessage method 
    @mock.patch("Create_Web_Service_Support.Client.service")
    def test_create_web_service_send_message(self, mock_create_service):

        mock_supplier_data=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        mock_response = response
        mock_response.status_code = 200
        mock_response.content= "Success"

        json_file_config =Suppliers.read_config()

        mock_create_service.createSupplier.return_value = mock_response
       
        supp = Create_Web_Service_Support(json_file_config['Oracle_user'], json_file_config['Oracle_password'], json_file_config['Oracle_WSDL'])  
        res , err_msg = supp.send_message(mock_supplier_data)

        
        self.assertEqual(res.status_code , 200)

    #test case end


    #test case for Update_Web_Service_Support testing sendMessage method
    @mock.patch("Create_Web_Service_Support.Client.service")
    def test_update_web_service_send_message(self, mock_create_service):

        mock_supplier_data=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        mock_response = response
        mock_response.status_code = 200
        mock_response.content= "Success"

        json_file_config =Suppliers.read_config()

        mock_create_service.updateSupplier.return_value = mock_response
       
        supp = Update_Web_Service_Support(json_file_config['Oracle_user'], json_file_config['Oracle_password'], json_file_config['Oracle_WSDL'])  
        res , err_msg = supp.send_message(mock_supplier_data, "40844", "44-444545")

        
        self.assertEqual(res.status_code , 200)

    #test case end


    #test case for FRMS_Support testing scanForCreateRecord method 

    def test_scan_for_create_records(self):

        expected=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all") 
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor
       
        f = FRMS_Support("testing", mock_connection, mock_connection)  
        res = f.scan_for_create_record()
        
        self.assertEqual(res, expected)

    #test case end

    #test case for FRMS_Support testing scanForUpdateRecord method 

    def test_scan_for_Update_records(self):

        expected=[(56666444418888888, 'Completed', '40844', '52f8e6da-0428-46ea-9770-047f50c2251c', 'N/A', '75018', 'not legally required', 'US_Dollar', 'paris', 'FR', None, datetime(2022, 1, 4, 17, 15, 43, 710000), '3 rue des trois freres', '', 'emmanuel rodriguez', 'idf', 'FR', 'WIRE', 'USD', False, True, True, 'emmanuel', None, False, 'SPEND_AUTHORIZED', True, 'fr7624599619092729243010188', True, 'milleis', 'NA', 'CREATE', 'SEG Worldwide', 'SEG Worldwide', 'NA\r\n', 'SSN', '40844', 'emmanuel rodriguez', 'SEG Worldwide', 'privfrpp', True, 'emmanuel.r.maroto@restoflash.fr', 'rodriguez', 'Non-US Mendix Consultant', 'NA', '27292430101', True, 'default', True, 'CORPORATION', False, False, False, False, None, None, False)]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all") 
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor
       
        f = FRMS_Support("testing", mock_connection, mock_connection)  
        res = f.scan_for_update_record()
        
        self.assertEqual(res, expected)

    #test case end

    #test case for FRMS_Support testing getTaxpayerID method 

    def test_get_taxpayer_id(self):

        expected=[("44-333343")]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all") 
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor
       
        f = FRMS_Support("testing", mock_connection, mock_connection)  
        res = f.get_taxpayer_id(40844)
        
        self.assertEqual(res, expected)

    #test case end


    #test case for FRMS_Support testing getSupplierName method 

    def test_get_supplier_name(self):

        expected=[("44-333343")]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all") 
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor
       
        f = FRMS_Support("testing", mock_connection, mock_connection)  
        res = f.get_supplier_name(40844)
        
        self.assertEqual(res, expected)

    #test case end


            
 

     
    
