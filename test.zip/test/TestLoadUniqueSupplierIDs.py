

import os
import argparse
from unittest import TestCase, mock
from datetime import date
import tempfile
from SEG.utils.SEGUtils import  get_app_work_dir
import LoadUniqueSupplierIDs



class TestLoadUniqueSupplierIDs(TestCase):
    root_directory = tempfile.mkdtemp()
    debug= True
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    log_config_file=os.environ.get("PY_LOG_CONFIG")
    sql_section_name="test"
    source_file=os.path.join(get_app_work_dir(), "test_uniqueSupplierIDList.xlsx")
    target_database_table="Test"
 


    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                sourceFile=source_file,
                targetDatabaseTable=target_database_table))
    def test_process_local_variables(self, args):
        
        param_variables, ret_code = LoadUniqueSupplierIDs.process_local_variables()

        self.assertEqual(ret_code, 0)


    def test_source_file_exists(self):

        self.assertTrue(os.path.exists(self.source_file))



    @mock.patch('LoadUniqueSupplierIDs.get_db_connection')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                sourceFile=source_file,
                targetDatabaseTable=target_database_table))
    def test_workflow_connection_fail(self, args, mock_conn):
        
        mock_conn.return_value = -1,  ''

        with self.assertRaises(SystemExit) as sye:
               LoadUniqueSupplierIDs.main()

        
        self.assertEqual(sye.exception.code , -1)


    @mock.patch('LoadUniqueSupplierIDs.execute_sql_query')
    @mock.patch('LoadUniqueSupplierIDs.get_db_connection')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                sourceFile=source_file,
                targetDatabaseTable=target_database_table))
    def test_workflow_with_susses(self, args, mock_conn, mock_exc_query):
        
        mock_conn.return_value = 0,  ''
        mock_exc_query.return_value = 0

         
        ret = LoadUniqueSupplierIDs.main()

        
        self.assertEqual(ret, 0)
        
 
   