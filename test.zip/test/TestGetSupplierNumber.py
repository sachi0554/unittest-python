
import os
import argparse
from unittest import TestCase, mock
from datetime import date
import GetSupplierNumber
from GetSupplierNumberSupport import GetSupplierNumberSupport


class TestGetSupplierNumber(TestCase):
    debug= True
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    log_config_file=os.environ.get("PY_LOG_CONFIG")
    oracle_mode="test"
    fusion_user_id="test"
    fusion_secert="test"
    contact_id="Test123"


    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user_id,
                FusionPassword=fusion_secert,
                contactID=contact_id))
    def test_process_local_variables(self, args):
        
        param_variables, ret_code = GetSupplierNumber.process_local_variables()

        self.assertEqual(ret_code, 0)



    @mock.patch("GetSupplierNumberSupport.Client.service")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user_id,
                FusionPassword=fusion_secert,
                contactID=contact_id))
    def test_get_supplier_number_if_success(self,args,mock_soap_request):
        mock_response={}
        mock_response["status_code"] = 200
        mock_response["reportBytes"]= b'1\nTest2'


        mock_soap_request.runReport.return_value = mock_response

        param_variables, ret_code = GetSupplierNumber.process_local_variables()

        supp = GetSupplierNumberSupport(param_variables)

        result, error = supp.get_supplier_number(param_variables["contactID"])

        self.assertEqual(error, "Success")


    @mock.patch("GetSupplierNumberSupport.Client.service")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user_id,
                FusionPassword=fusion_secert,
                contactID=contact_id))
    def test_get_supplier_number_if_failed(self,args,mock_soap_request):
        mock_response={}

        mock_response["reportBytes"]= 12


        mock_soap_request.runReport.side_effect = Exception

        param_variables, ret_code = GetSupplierNumber.process_local_variables()


        supp = GetSupplierNumberSupport(param_variables)

        with self.assertRaises(Exception):
             supp.get_supplier_number(param_variables["contactID"])


    @mock.patch("GetSupplierNumberSupport.Client.service")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                 log_config_file=log_config_file, 
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user_id,
                FusionPassword=fusion_secert,
                contactID=contact_id))
    def test_workflow_with_susses(self,args,mock_soap_request):
        mock_response={}
        mock_response["status_code"] = 200
        mock_response["reportBytes"]= b'1\nTest2'


        mock_soap_request.runReport.return_value = mock_response

        ret_code = GetSupplierNumber.main()

         
        self.assertEqual(ret_code, 0)


    @mock.patch.object(GetSupplierNumberSupport, "get_supplier_number")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user_id,
                FusionPassword=fusion_secert,
                contactID=contact_id))
    def test_workflow_with_error(self,args,mock_get_supplier_number):

        mock_get_supplier_number.return_value = "Test", "error"

        ret_code = GetSupplierNumber.main()

         
        self.assertEqual(ret_code, 0)
    

        


