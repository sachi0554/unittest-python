
from datetime import date
import os
from unittest import TestCase, mock                               
import argparse
import SetSupplierPaymentMethod
from urllib import response


class TestSetSupplierPaymentMethod(TestCase):
    debug= True
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    log_config_file=os.environ.get("PY_LOG_CONFIG")
    mode="test"
    fusion_user="Test"
    fusion_secert="Test"    


    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert))
    def test_process_local_variables(self, args):
        
        param_variables, ret_code = SetSupplierPaymentMethod.process_local_variables()

        self.assertEqual(ret_code, 0)

    def test_representInt_is_int(self):

        result = SetSupplierPaymentMethod.represents_int("54")  

        self.assertEqual(result, True)    

    def test_representInt_not_int(self):

        result = SetSupplierPaymentMethod.represents_int("abc")

        self.assertEqual(result, False)     


    @mock.patch("SetSupplierPaymentMethod.Client.service")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert))
    def test_client_soap_request_success(self, args, mock_soap_request):
        
        param_variables, ret_code = SetSupplierPaymentMethod.process_local_variables()

        mock_response=response
        mock_response.reportBytes = b'1\nTest2'

        mock_soap_request.runReport.return_value = mock_response       

        result = SetSupplierPaymentMethod.client_soap_request(param_variables)

        self.assertEqual(result, mock_response)


    @mock.patch("SetSupplierPaymentMethod.Client.service")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert))
    def test_client_soap_request_on_exception(self, args, mock_soap_request):
        
        param_variables, ret_code = SetSupplierPaymentMethod.process_local_variables()

        mock_soap_request.runReport.side_effect = Exception("Server error!")    

        result = SetSupplierPaymentMethod.client_soap_request(param_variables)
        self.assertEqual(result, None)


    def test_extract_usable_ids_is_int(self):

        id_list = [1,2]

        result = SetSupplierPaymentMethod.extract_usable_ids(id_list)

        self.assertEqual(result, id_list) 

    def test_extract_usable_ids_not_int(self):

        id_list = [1,"abc"]

        result = SetSupplierPaymentMethod.extract_usable_ids(id_list) 

        self.assertEqual(result, [1])    


    @mock.patch("SetSupplierPaymentMethod.requests.post")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert))    
    def test_rest_service_success(self, args, mock_rest_service):  

        usable=["1","2","3"]

        mock_res= response
        mock_res.content= "any"

        param_variables, ret_code = SetSupplierPaymentMethod.process_local_variables()

        mock_rest_service.return_value = mock_res

        result = SetSupplierPaymentMethod.rest_service(usable ,param_variables)

        self.assertEqual(result, None)        


    @mock.patch("SetSupplierPaymentMethod.requests.post")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert))    
    def test_rest_service_on_exception(self, args, mock_rest_service):  

        usable=["1","2","3"]
        param_variables, ret_code = SetSupplierPaymentMethod.process_local_variables()

        mock_rest_service.side_effect = Exception("Server error!")

        result = SetSupplierPaymentMethod.rest_service(usable ,param_variables)

        self.assertNotEqual(result, None) 



    @mock.patch("SetSupplierPaymentMethod.rest_service")
    @mock.patch("SetSupplierPaymentMethod.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert)) 
    def test_workflow_with_rest_service_if_success(self, arg, mock_client_soap, mock_rest_service):

        mock_res= response
        mock_res.reportBytes= b'1\nTest2'

        mock_client_soap.return_value = mock_res

        mock_rest_service.return_value = None

        result = SetSupplierPaymentMethod.main()

        self.assertEqual(result, 0)   

    @mock.patch("SetSupplierPaymentMethod.rest_service")
    @mock.patch("SetSupplierPaymentMethod.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert)) 
    def test_workflow_with_rest_service_rest_service_not_none(self, arg, mock_client_soap, mock_rest_service):

        mock_res= response
        mock_res.reportBytes= b'1\nTest2'

        mock_client_soap.return_value = mock_res

        mock_rest_service.return_value = "Server error!"

        result = SetSupplierPaymentMethod.main()

        self.assertEqual(result, -1)  

    @mock.patch("SetSupplierPaymentMethod.rest_service")
    @mock.patch("SetSupplierPaymentMethod.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                log_config_file=log_config_file, 
                mode=mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert)) 
    def test_workflow_with_rest_service_client_soap_request_is_none(self, arg, mock_client_soap, mock_rest_service):

        mock_client_soap.return_value = None

        result = SetSupplierPaymentMethod.main()

        self.assertEqual(result, -1)                               






