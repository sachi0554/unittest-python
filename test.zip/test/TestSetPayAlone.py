
from unittest import TestCase, mock
from urllib import response                               
import argparse
import SetPayAlone
from SetPayAlone import client_soap_request, rest_service, read_config


class TestSetPayAlone(TestCase):
    log_level="INFO"  
    report_bytes = b'1\nTest2'


    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level=log_level, 
               ))
    def test_process_local_variables(self , mock_args):

        options = SetPayAlone.read_commandline_args()

        self.assertEqual(options.log_level, self.log_level)



    def test_read_config_file(self):

        json_file_config = SetPayAlone.read_config()

        self.assertIsNotNone(json_file_config)

    @mock.patch("SetPayAlone.Client.service")
    def test_soap_service(self, mock_soap_request):

        mock_response=response
        mock_response.status_code = 200
        mock_response.content=tuple(["value1", "value2"])

        json_file_config = read_config()

        mock_soap_request.runReport.return_value = mock_response

        wsdl= json_file_config['WSDL']
        user = json_file_config['user']
        password = json_file_config['password']

        result = client_soap_request(wsdl, user, password)

        self.assertEqual(result.status_code , 200)
        self.assertIsNotNone(result.content)



    @mock.patch("SetPayAlone.Client.service")
    def test_soap_service_with_none_response(self, mock_soap_request):

        mock_response=response
        mock_response.status_code = 200
        mock_response.content=None

        json_file_config = read_config()

        mock_soap_request.runReport.return_value = mock_response

        wsdl= json_file_config['WSDL']
        user = json_file_config['user']
        password = json_file_config['password']

        result = client_soap_request(wsdl, user, password)

        self.assertIsNone(result.content)
 
    def test_extract_usable_ids_is_int(self):

        id_list = [1,2]

        result = SetPayAlone.extract_usable_ids(id_list)

        self.assertEqual(result, id_list) 



    def test_extract_usable_ids_not_int(self):

        id_list = [1,"abc"]

        result = SetPayAlone.extract_usable_ids(id_list) 

        self.assertEqual(result, [1]) 



    def test_representInt_is_int(self):

        result = SetPayAlone.represents_int("54")  

        self.assertEqual(result, True)    



    def test_representInt_not_int(self):

        result = SetPayAlone.represents_int("abc")

        self.assertEqual(result, False)   




    @mock.patch("SetPayAlone.requests.patch")
    def test_rest_service_result_is_none(self, mock_rest_service):

        mock_res= response
        mock_res.content= "any"
        mock_res.status= 200

        json_file_config = read_config()

        wsdl= json_file_config['WSDL']
        user = json_file_config['user']
        password = json_file_config['password']

        mock_rest_service.return_value = mock_res

        result = rest_service(["1","2"], wsdl, user, password)

        self.assertEqual(result, None) 

    @mock.patch("SetPayAlone.requests.patch")
    def test_rest_service_on_expection(self, mock_rest_service):

        mock_res= response
        mock_res.content= "any"
        mock_res.status= 200 

        json_file_config = read_config()  

        wsdl= json_file_config['WSDL']
        user = json_file_config['user']
        password = json_file_config['password']

        mock_rest_service.side_effect = Exception("Server error!") 

        result = rest_service(["1","2"], wsdl, user, password)

        self.assertNotEqual(result, None) 



    @mock.patch("SetPayAlone.rest_service")
    @mock.patch("SetPayAlone.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level="INFO", 
               ))
    def test_workflow_with_rest_service_if_success(self, arg, mock_client_soap, mock_rest_service):

        mock_res= response
        mock_res.reportBytes= self.report_bytes

        mock_client_soap.return_value = mock_res

        mock_rest_service.return_value = None

        result = SetPayAlone.main()

        self.assertEqual(result, 0) 



    @mock.patch("SetPayAlone.read_config")
    @mock.patch("SetPayAlone.rest_service")
    @mock.patch("SetPayAlone.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level="INFO", 
               ))
    def test_workflow_with_read_config_is_none(self, arg, mock_client_soap, mock_rest_service, mock_read_config):

        mock_res= response
        mock_res.reportBytes= self.report_bytes

        mock_client_soap.return_value = mock_res

        mock_rest_service.return_value = None

        mock_read_config.return_value = {}

        result = SetPayAlone.main()

        self.assertEqual(result, -1) 



    @mock.patch("SetPayAlone.rest_service")
    @mock.patch("SetPayAlone.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level="INFO", 
               ))
    def test_workflow_with_client_soap_response_failed(self, arg, mock_client_soap, mock_rest_service):

        mock_client_soap.return_value = None
        mock_rest_service.return_value = None

        result = SetPayAlone.main()

        self.assertEqual(result, -1) 

        

    @mock.patch("SetPayAlone.rest_service")
    @mock.patch("SetPayAlone.client_soap_request")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level="INFO", 
               ))
    def test_workflow_with_rest_service_if_failed(self, arg, mock_client_soap, mock_rest_service):

        mock_res= response
        mock_res.reportBytes= self.report_bytes

        mock_client_soap.return_value = mock_res

        mock_rest_service.return_value = "failed to call rest service"

        result = SetPayAlone.main()
        
        self.assertEqual(result, -1)                     