import os
from unittest import TestCase , mock
import argparse
from datetime import date

import UpdateSuppliers
from Update_Web_Service_One_Off_Support import Update_Web_Service_One_Off_Support 
from FRMS_Support_For_Update_Only import FRMS_Support_For_Update_Only




class TestUpdateSuppliers(TestCase):

    debug = False
    jams_id = "test_"+date.today().strftime('%Y%m%d%H%M%S')
    log_config_file = os.environ.get("PY_LOG_CONFIG")
    sql_section_name1 = "test"
    sql_section_name2 = "test2"
    frms_mode = "test"
    oracle_mode = "test"
    fusion_user = "jnevin"
    fusion_secert = "Welcome1!"


    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id="",
                sqlSectionName1=sql_section_name1,
                sqlSectionName2=sql_section_name2, 
                log_config_file=log_config_file,
                FRMS_mode=frms_mode,
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert
                ))
    def test_process_local_variable(self, args):

         param_variables, ret = UpdateSuppliers.process_local_variables()

         self.assertEqual(ret, 0)
         self.assertEqual(param_variables["debug"] , self.debug)
         self.assertEqual(param_variables["sqlSectionName1"] , self.sql_section_name1)
         self.assertEqual(param_variables["sqlSectionName2"] , self.sql_section_name2)
         self.assertEqual(param_variables["log_config_file"] , self.log_config_file)
         self.assertEqual(param_variables["FRMS_mode"] , self.frms_mode)
         self.assertEqual(param_variables["ORACLE_mode"] , self.oracle_mode)
         self.assertEqual(param_variables["FusionUser"] , self.fusion_user)
         self.assertEqual(param_variables["FusionPassword"] , self.fusion_secert)
    

    #test case for FRMS_Support_For_Update_Only testing scanForUpdateRecord method 

    def test_scan_for_update_records(self):
        param_variables= {}
        param_variables['FRMS_mode']= "test"
        expected=[("Sample1",	"Default",	"Default",	"36816"	,"US"),("Sample2", "Default", "Default", "34560",	"US")]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all") 
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor

        supp = FRMS_Support_For_Update_Only(param_variables, mock_connection, mock_connection)
        result = supp.scan_for_update_record()


        self.assertEqual(result, expected)

    #test case end

    #test case db connection failed for Main method
    @mock.patch('UpdateSuppliers.get_db_conn1')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id="",
                sqlSectionName1=sql_section_name1,
                sqlSectionName2=sql_section_name2, 
                log_config_file=log_config_file,
                FRMS_mode=frms_mode,
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert
                ))
    def test_workflow_db_connection1_failed(self, args, mock_db_conn):
         
        mock_db_conn.return_value = -1 , ''


        with self.assertRaises(SystemExit) as sye:
               UpdateSuppliers.main()

        self.assertEqual(sye.exception.code, -1)

    #test case end

    #test case db connection failed for Main method
    @mock.patch('UpdateSuppliers.get_db_conn2')
    @mock.patch('UpdateSuppliers.get_db_conn1')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id="",
                sqlSectionName1=sql_section_name1,
                sqlSectionName2=sql_section_name2, 
                log_config_file=log_config_file,
                FRMS_mode=frms_mode,
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert
                ))
    def test_workflow_db_connection2_failed(self, args, mock_db_conn1, mock_db_conn2):
        conn = mock.Mock(name="db_conn")
        mock_db_conn1.return_value = 0 , conn
        mock_db_conn2.return_value = -1 , conn

        with self.assertRaises(SystemExit) as sye:
               UpdateSuppliers.main()

        self.assertEqual(sye.exception.code, -1)

    #test case end


     #test case workflow for scanForUpdateRecord and sendMessage method 
    @mock.patch.object(Update_Web_Service_One_Off_Support, 'send_message')
    @mock.patch.object(FRMS_Support_For_Update_Only, 'scan_for_update_record')
    @mock.patch('UpdateSuppliers.get_db_conn2')
    @mock.patch('UpdateSuppliers.get_db_conn1')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id="",
                sqlSectionName1=sql_section_name1,
                sqlSectionName2=sql_section_name2, 
                log_config_file=log_config_file,
                FRMS_mode=frms_mode,
                ORACLE_mode=oracle_mode,
                FusionUser=fusion_user,
                FusionPassword=fusion_secert
                ))
    def test_workflow_for_success(self, args, mock_db_conn1, mock_db_conn2, mock_scan_for_update_records, mock_send_mesage):

        conn = mock.Mock(name="db_conn")
        mock_db_conn1.return_value = 0 , conn
        mock_db_conn2.return_value = 0 , conn
        mock_scan_for_update_records.return_value = [("Sample1",	"Default",	"Default",	"36816"	,"US"),("Sample2", "Default", "Default", "34560",	"US")]
        mock_send_mesage.return_value= 0 , ''

       
        ret = UpdateSuppliers.main()

       

        self.assertEqual(ret, 0)
        self.assertEqual(mock_send_mesage.call_count, 2)

    #test case end
          





 



    
        


         
