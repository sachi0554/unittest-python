from datetime import date
import os
from unittest import TestCase, mock                               
from urllib import response
import argparse
import UpdateFoundationSuppliers
from SEG.utils.SEGUtils import  get_app_work_dir
from UpdateFoundationSuppliersSupport import UpdateFoundationSuppliersSupport

class TestUpdateFoundationSupplier(TestCase):
    log_level="INFO" 
    source_file = os.path.join(get_app_work_dir(), "test_foundationSuppliersSourceFile.xlsx")
    db_conn =  ""


    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level=log_level, 
               ))
    def test_process_local_variables(self , mock_args):

        options = UpdateFoundationSuppliers.read_commandline_args()

        self.assertEqual(options.log_level, self.log_level)



    def test_extract_config_exists(self):

        result = UpdateFoundationSuppliers.extract_config()

        self.assertGreater(len(result),0)


    def test_update_foundation_suppliers_support_getdata(self):

        expected_result = [{'fluxxID': '10328270', 'organization': 'American Ass. of Community Theatre', 
        'contactAddress1': 'PO Box 101476', 'contactAddress2': '', 'city': 'Fort Worth', 'state': 'TX',
        'zip': '76185-1476', 'taxID': '47-0692296'}, 
        {'fluxxID': '10080075', 'organization': 'American Lung Association', 'contactAddress1': '55 W. Wacker Drive, Suite 1150',
        'contactAddress2': '', 'city': 'Chicago', 'state': 'IL', 'zip': '60601', 'taxID': '13-1632524'}, 
        {'fluxxID': '10005421', 'organization': 'Ali Forney Center', 'contactAddress1': '224 W. 35th Street', 
        'contactAddress2': '15th Floor', 'city': 'New York', 'state': 'NY', 'zip': '10001', 'taxID': '30-0104507'}]

        result = UpdateFoundationSuppliers.extract_config()

        fusion_user = result['Fusion_user']
        fusion_password = result['Fusion_password']
        oracle_wsdl = result['Oracle_WSDL']

        update_foundation = UpdateFoundationSuppliersSupport(fusion_user, fusion_password, oracle_wsdl, self.source_file, self.db_conn)

        data = update_foundation.get_data()
        
        self.assertEqual(len(expected_result), len(data))
        self.assertEqual(expected_result[0], data[0])
        self.assertEqual(expected_result[1], data[1])
        self.assertEqual(expected_result[2], data[2])


    @mock.patch("UpdateFoundationSuppliersSupport.Client.service")
    def test_update_foundation_suppliers_support_send_create_message(self,mock_send_message):

        result = UpdateFoundationSuppliers.extract_config()

        fusion_user = result['Fusion_user']
        fusion_password = result['Fusion_password']
        oracle_wsdl = result['Oracle_WSDL']        

        update_foundation = UpdateFoundationSuppliersSupport(fusion_user, fusion_password, oracle_wsdl, self.source_file, self.db_conn)

        mock_response=response
        mock_response.status_code = 200
        mock_response.content= 'Success'

        mock_send_message.createSupplier.return_value = mock_response

        data = update_foundation.get_data()

        for item in data:

            result = update_foundation.send_create_message(item)

        self.assertEqual(result.content, 'Success')
        


    @mock.patch("UpdateFoundationSuppliersSupport.Client.service")
    def test_update_foundation_suppliers_support_send_create_message_on_exception(self,mock_send_message):

        result = UpdateFoundationSuppliers.extract_config()

        fusion_user = result['Fusion_user']
        fusion_password = result['Fusion_password']
        oracle_wsdl = result['Oracle_WSDL']        

        update_foundation = UpdateFoundationSuppliersSupport(fusion_user, fusion_password, oracle_wsdl, self.source_file, self.db_conn)

        mock_send_message.createSupplier.side_effect = Exception("Server error!") 

        data = update_foundation.get_data()

        for item in data:

            result = update_foundation.send_create_message(item)

        self.assertEqual(result, '')        
  

    @mock.patch("UpdateFoundationSuppliersSupport.Client.service")
    def test_update_foundation_suppliers_support_send_update_message(self,mock_send_message):

        result = UpdateFoundationSuppliers.extract_config()

        fusion_user = result['Fusion_user']
        fusion_password = result['Fusion_password']
        oracle_wsdl = result['Oracle_WSDL']

        update_foundation = UpdateFoundationSuppliersSupport(fusion_user, fusion_password, oracle_wsdl, self.source_file, self.db_conn)

        mock_response=response
        mock_response.status_code = 200
        mock_response.content= 'Success'

        mock_send_message.updateSupplier.return_value = mock_response

        data = update_foundation.get_data()

        for item in data:

            result = update_foundation.send_update_message(item,"")

        self.assertEqual(result.content, 'Success')


    @mock.patch("UpdateFoundationSuppliersSupport.Client.service")
    def test_update_foundation_suppliers_support_send_update_message_on_exception(self,mock_send_message):

        result = UpdateFoundationSuppliers.extract_config()

        fusion_user = result['Fusion_user']
        fusion_password = result['Fusion_password']
        oracle_wsdl = result['Oracle_WSDL']        

        update_foundation = UpdateFoundationSuppliersSupport(fusion_user, fusion_password, oracle_wsdl, self.source_file, self.db_conn)

        mock_send_message.updateSupplier.side_effect = Exception("Server error!") 

        data = update_foundation.get_data()

        for item in data:

            result = update_foundation.send_update_message(item,"")

        self.assertEqual(result, '')    



    def test_get_supplier_number(self):

        expected = [(10328),(10333)]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all")  # I needed to mock this as well
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor 

        result = UpdateFoundationSuppliers.extract_config()

        fusion_user = result['Fusion_user']
        fusion_password = result['Fusion_password']
        oracle_wsdl = result['Oracle_WSDL']

        update_foundation = UpdateFoundationSuppliersSupport(fusion_user, fusion_password, oracle_wsdl, self.source_file, mock_connection)

        result_get_supplier_number = update_foundation.get_supplier_number(2)  

        self.assertEqual(result_get_supplier_number, expected)  



    @mock.patch.object(UpdateFoundationSuppliersSupport,"send_update_message")
    @mock.patch.object(UpdateFoundationSuppliersSupport,"send_create_message")
    @mock.patch.object(UpdateFoundationSuppliersSupport,"get_supplier_number")
    @mock.patch.object(UpdateFoundationSuppliersSupport,"get_data")
    @mock.patch("UpdateFoundationSuppliers.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level=log_level, 
               ))
    def test_workflow_with_rest_service_if_success(self, arg, mock_db_conn, mock_get_data, mock_get_supplier_number, mock_send_create_message, mock_send_update_message):

        mock_data = [{'fluxxID': '10328270', 'organization': 'American Ass. of Community Theatre', 
        'contactAddress1': 'PO Box 101476', 'contactAddress2': '', 'city': 'Fort Worth', 'state': 'TX',
        'zip': '76185-1476', 'taxID': '47-0692296'}, 
        {'fluxxID': '10080075', 'organization': 'American Lung Association', 'contactAddress1': '55 W. Wacker Drive, Suite 1150',
        'contactAddress2': '', 'city': 'Chicago', 'state': 'IL', 'zip': '60601', 'taxID': '13-1632524'}, 
        {'fluxxID': '10005421', 'organization': 'Ali Forney Center', 'contactAddress1': '224 W. 35th Street', 
        'contactAddress2': '15th Floor', 'city': 'New York', 'state': 'NY', 'zip': '10001', 'taxID': '30-0104507'}]

        mock_db_conn.return_value = ""
        mock_get_data.return_value = mock_data
        mock_get_supplier_number.return_value = [[(0,1),(1,2)]]
        mock_send_create_message.return_value = 'Success'
        mock_send_update_message.return_value = 'Success'

        result = UpdateFoundationSuppliers.main()

        self.assertEqual(result, 0)  
        self.assertEqual(mock_send_create_message.call_count, 0)
        self.assertEqual(mock_send_update_message.call_count, 3)    


    @mock.patch.object(UpdateFoundationSuppliersSupport,"send_update_message")
    @mock.patch.object(UpdateFoundationSuppliersSupport,"send_create_message")
    @mock.patch.object(UpdateFoundationSuppliersSupport,"get_supplier_number")
    @mock.patch.object(UpdateFoundationSuppliersSupport,"get_data")
    @mock.patch("UpdateFoundationSuppliers.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level=log_level, 
               ))
    def test_workflow_with_rest_service_on_success_get_supplier_number_none(self, arg, mock_db_conn, mock_get_data, mock_get_supplier_number, mock_send_create_message, mock_send_update_message):

        mock_data = [{'fluxxID': '10328270', 'organization': 'American Ass. of Community Theatre', 
        'contactAddress1': 'PO Box 101476', 'contactAddress2': '', 'city': 'Fort Worth', 'state': 'TX',
         'zip': '76185-1476', 'taxID': '47-0692296'}, 
         {'fluxxID': '10080075', 'organization': 'American Lung Association', 'contactAddress1': '55 W. Wacker Drive, Suite 1150',
          'contactAddress2': '', 'city': 'Chicago', 'state': 'IL', 'zip': '60601', 'taxID': '13-1632524'}, 
          {'fluxxID': '10005421', 'organization': 'Ali Forney Center', 'contactAddress1': '224 W. 35th Street', 
          'contactAddress2': '15th Floor', 'city': 'New York', 'state': 'NY', 'zip': '10001', 'taxID': '30-0104507'}]

        mock_db_conn.return_value = ""
        mock_get_data.return_value = mock_data
        mock_get_supplier_number.return_value = [[(),()]]
        mock_send_create_message.return_value = 'Success'
        mock_send_update_message.return_value = 'Success'

        result = UpdateFoundationSuppliers.main()

        self.assertEqual(result, 0)  
        self.assertEqual(mock_send_create_message.call_count, 3)
        self.assertEqual(mock_send_update_message.call_count, 0)              



    @mock.patch("UpdateFoundationSuppliers.extract_config")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(  
                log_level=log_level, 
               ))
    def test_workflow_with_config_json_not_found(self, arg, mock_extract_config):

        mock_extract_config.return_value = {}

        result = UpdateFoundationSuppliers.main()

        self.assertEqual(result, -1)                


          
      