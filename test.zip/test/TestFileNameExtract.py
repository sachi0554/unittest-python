

import unittest 
from filename_extract import get_filename


class TestFileNameExtract(unittest.TestCase):


    def test_process_get_email_key(self):
        #os path
        filepath="C:/Users/supadhyay/Documents/workspace/Oracle-Automation-AP/work/test.csv"
        
        #windows
        filepath2="C:\\Users\\supadhyay\\Documents\workspace\\Oracle-Automation-AP\\pending\\MasterTestfile_view_0010302-0802-3434.csv"

        #Linux 
        filepath3="/fesdev/qa3/Oracle-Automation-AP/work/MasterTestfile_view_0010302-0802-3434.csv"
        
        exp = "test.csv"
        res = get_filename(filepath)
        self.assertEqual(res, exp)

        exp= "MasterTestfile_view_0010302-0802-3434.csv"
        res = get_filename(filepath2)
        self.assertEqual(res, exp)

        exp= "MasterTestfile_view_0010302-0802-3434.csv"
        res = get_filename(filepath3)
        print(res)
        self.assertEqual(res, exp)
 