
from datetime import date
import os
from unittest import TestCase, mock                               
import argparse
import shutil
import tempfile
import UnresolvedErrorsNotify
from SEG.utils.SEGUtils import  get_app_work_dir
from UnresolvedErrorsNotifySupport import UnresolvedErrorsNotifySupport


class TestUnresolvedErrorsNotify(TestCase):

    root_directory = tempfile.mkdtemp()
    debug= True
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    notificationFile=os.path.join(root_directory, "test_unresolved_errors_.xlsx")
    sql_section_name="test"
    frms_mode="test"
    log_config_file=os.environ.get("PY_LOG_CONFIG")
    

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)

    # Local Variable process check

    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_process_local_variables(self, args):
        
        param_variables, ret_code = UnresolvedErrorsNotify.process_local_variables()

        self.assertEqual(ret_code, 0)

    # End of Test


    # Send Email Methord Success Check

    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_send_email_success(self, args):
        
        param_variables, ret_code = UnresolvedErrorsNotify.process_local_variables()

        result = UnresolvedErrorsNotify.send_email(param_variables)

        self.assertEqual(ret_code, 0)  
        self.assertEqual(result, 0) 

    # End of Test
       
       
    # Send Email Methoed Parameter Not Found Check

    def test_send_email_no_param_variables(self):
        
        result = UnresolvedErrorsNotify.send_email("")
 
        self.assertEqual(result, -1)  

    # End of Test   


    # UnresolvedErrorsNotifySupport scan_for_unresolved_error_records Checking with mocking  

    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_scan_unresolved_error_records_success(self, mock_args):

        expected = [("Sample Supplier01", "49290", "123-25-1234", "Sample01"," Supplier01")]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all")  # I needed to mock this as well
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor         

        param_variables, ret_code = UnresolvedErrorsNotify.process_local_variables()

        uens = UnresolvedErrorsNotifySupport(param_variables, mock_connection)

        result_set = uens.scan_for_unresolved_error_records()

        self.assertEqual(result_set, expected) 
        self.assertTrue(os.path.exists(self.notificationFile))        

    # End of Test   


    # UnresolvedErrorsNotifySupport captureUnresolvedEntries Checking with mocking

    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_unresolved_error_capture_records_success(self, mock_args):

        expected = [("Sample Supplier01", "49290", "123-25-1234", "Sample01"," Supplier01")]
        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all")  # I needed to mock this as well
        mock_fetch_all.fetchall.return_value = expected
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor         

        param_variables, ret_code = UnresolvedErrorsNotify.process_local_variables()

        supp = UnresolvedErrorsNotifySupport(param_variables, mock_connection)
        size_before = os.path.getsize(self.notificationFile)

        result_set = supp.scan_for_unresolved_error_records()

        supp.capture_unresolved_entries(result_set)
        size_after = os.path.getsize(self.notificationFile)

        self.assertGreater(size_after, size_before)

    # End of Test      


    # Workflow With Success

    @mock.patch.object(UnresolvedErrorsNotifySupport,"scan_for_unresolved_error_records")
    @mock.patch("UnresolvedErrorsNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_workflow_with_rest_service_if_success(self, mock_args, mock_db_conn, mock_unresolved_errors_notify):  

        expected = [("Sample Supplier01", "49290", "123-25-1234", "Sample01"," Supplier01")]

        mock_db_conn.return_value = 0 , ''

        mock_unresolved_errors_notify.return_value = expected

        result = UnresolvedErrorsNotify.main()

        self.assertEqual(result, 0) 

    # End of Test            


    # Workflow With fail db connection

    @mock.patch.object(UnresolvedErrorsNotifySupport,"scan_for_unresolved_error_records")
    @mock.patch("UnresolvedErrorsNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_workflow_with_rest_service_if_db_conn_fails(self, mock_args, mock_db_conn, mock_unresolved_errors_notify):  

        expected = [("Sample Supplier01", "49290", "123-25-1234", "Sample01"," Supplier01")]

        mock_db_conn.return_value = -1 , ''

        mock_unresolved_errors_notify.return_value = expected

        with self.assertRaises(SystemExit):
            UnresolvedErrorsNotify.main()

    # End of Test     


    # Workflow With no records in unresolved error records

    @mock.patch.object(UnresolvedErrorsNotifySupport,"scan_for_unresolved_error_records")
    @mock.patch("UnresolvedErrorsNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notificationFile=notificationFile,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_workflow_with_rest_service_if_no_record_for_unresolved_error_records(self, mock_args, mock_db_conn, mock_unresolved_errors_notify):  


        mock_db_conn.return_value = 0 , ''

        mock_unresolved_errors_notify.return_value = ''

        with self.assertRaises(SystemExit):
            UnresolvedErrorsNotify.main()

    # End of Test        