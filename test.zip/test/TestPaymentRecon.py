
from datetime import datetime, date
import os
import shutil
from unittest import TestCase, mock                               
import argparse
import tempfile
from SEG.utils.SEGUtils import  get_app_work_dir
import PaymentRecon
from PaymentReconSupport import PaymentReconSupport
import xlrd


class TestPaymentRecon(TestCase):

    root_directory = tempfile.mkdtemp()
    debug= True
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    FRMS_mode="test"
    sqlSectionName="test"
    reconFileName=os.path.join(root_directory, "test_PaymentRecon_.xlsx")
    extractFileName = os.path.join(get_app_work_dir(), "test_supplierExtract.csv")    

    log_config_file=os.environ.get("PY_LOG_CONFIG")


    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)

    # Local Variable process check

    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sqlSectionName, 
                log_config_file=log_config_file,
                reconFileName=reconFileName,
                extractFileName=extractFileName,
                FRMS_mode=FRMS_mode,
                subject="test subject"))
    def test_process_local_variables(self, mock_args):
        
        param_variables, ret_code = PaymentRecon.process_local_variables()

        self.assertEqual(ret_code, 0)

    # End of Test    


    # PaymentReconSupport with Success check and file value checking

    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sqlSectionName, 
                log_config_file=log_config_file,
                reconFileName=reconFileName,
                extractFileName=extractFileName,
                FRMS_mode=FRMS_mode,
                subject="test subject"))
    def test_payment_recon_support_success(self, mock_args):
        
        param_variables, ret_code = PaymentRecon.process_local_variables()

        date_value =  datetime(2022, 3, 25, 16, 0, 46, 304000)
        mock_data = [('FirstName1', 'LastName1', 61586, date_value,'Request1',1100),('FirstName2', 'LastName2', 93284, date_value,'Request2',1200)]

        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all")  # I needed to mock this as well
        mock_fetch_all.fetchall.return_value = mock_data
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor 

        payment_support = PaymentReconSupport(param_variables, mock_connection)

        return_value = payment_support.scan()
        payment_support.finalize()


        # Checking Value is displaying in sheet
        source_work_book = xlrd.open_workbook(self.reconFileName)
        id_found_sheet = source_work_book.sheet_by_index(0) 
        id_not_found_sheet = source_work_book.sheet_by_index(1) 


        self.assertEqual(mock_data[0][0], id_found_sheet.cell_value(1, 0))
        self.assertEqual(mock_data[0][4], id_found_sheet.cell_value(1, 4))
        self.assertEqual(mock_data[1][0], id_not_found_sheet.cell_value(1, 0))
        self.assertEqual(mock_data[1][4], id_not_found_sheet.cell_value(1, 4))        
        self.assertEqual(return_value, None)
        self.assertTrue(os.path.exists(self.extractFileName))

    # End of Test   
    

    # PaymentRecon Workflow With Success
    @mock.patch.object(PaymentReconSupport,"excute_sql_query")
    @mock.patch.object(PaymentReconSupport,"scan")
    @mock.patch("PaymentRecon.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sqlSectionName, 
                log_config_file=log_config_file,
                reconFileName=reconFileName,
                extractFileName=extractFileName,
                FRMS_mode=FRMS_mode,
                subject="test subject"))
    def test_workflow_with_rest_service_if_success(self, mock_args, mock_get_db_conn, mock_scan, mock_sql_query):  

        date_value =  datetime(2022, 3, 25, 16, 0, 46, 304000)
        mock_data = [('FirstName1', 'LastName1', 61586, date_value,'Request1',1100),('FirstName2', 'LastName2', 93284, date_value,'Request2',1200)]

        mock_connection = mock.Mock(name="db_conn2")
        mock_cursor = mock.Mock(name="mock_cursor")
        mock_fetch_all = mock.Mock(name="mock_fetch_all")  # I needed to mock this as well
        mock_fetch_all.fetchall.return_value = mock_data
        mock_cursor.execute.return_value = mock_fetch_all
        mock_connection.cursor.return_value = mock_cursor

        mock_get_db_conn.return_value =  0 , mock_connection
        mock_scan.return_value = 0
        mock_sql_query.return_value = mock_data

        retcode_value = PaymentRecon.main()

        self.assertEqual(retcode_value, 0)

    # End of Test   

    # PaymentRecon Workflow With DB connection fail

    @mock.patch("PaymentRecon.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sqlSectionName, 
                log_config_file=log_config_file,
                reconFileName=reconFileName,
                extractFileName=extractFileName,
                FRMS_mode=FRMS_mode,
                subject="test subject"))
    def test_workflow_with_rest_service_if_db_connection_fail(self, mock_args, mock_get_db_conn):  

        mock_get_db_conn.return_value =  -1 , ""

        with self.assertRaises(SystemExit):
            PaymentRecon.main()

    # End of Test   

