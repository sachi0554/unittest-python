

from unittest import TestCase, mock
import os
import argparse
from datetime import date
from SEG.utils.SEGUtils import  get_app_work_dir

import Notify

class TestNotify(TestCase):

    debug= True
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    log_config_file=os.environ.get("PY_LOG_CONFIG")
    sql_section_name="test"
    notifyContents=os.path.join(get_app_work_dir(), "test_notifyContents.xlsx")
    fail_notify_contents=os.path.join(get_app_work_dir(), "test_failnotifyContents.xlsx")
    frms_mode="test"



    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notifyContents=notifyContents,
                failnotifyContents=fail_notify_contents,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_process_local_variables(self, args):
        
        param_variables, ret_code = Notify.process_local_variables()

        self.assertEqual(ret_code, 0)


    @mock.patch('Notify.send_email')
    @mock.patch('Notify.get_db_conn')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notifyContents=notifyContents,
                failnotifyContents=fail_notify_contents,
                FRMS_mode=frms_mode, 
                subject="test subject"))
    def test_workflow_with_email_notify(self, args,mock_db_conn, mock_email_send):
        
        mock_db_conn.return_value= 0, ''
        
        ret_code = Notify.main()

        self.assertEqual(ret_code, 0)

        self.assertEqual(mock_email_send.call_count, 1)



    @mock.patch('Notify.get_db_conn')
    @mock.patch('argparse.ArgumentParser.parse_args',
            return_value=argparse.Namespace(
                debug=debug,
                jams_id=jams_id, 
                sqlSectionName=sql_section_name, 
                log_config_file=log_config_file,
                notifyContents=None,
                failnotifyContents=None,
                FRMS_mode=frms_mode,
                subject="test subject"))
    def test_workflow_with_capture_file_none_and_fail_file_none(self, args,mock_db_conn):
        
        mock_db_conn.return_value= 0, ''

        with self.assertRaises(SystemExit) as sye:
               Notify.main()

        
        self.assertEqual(sye.exception.code , 0)

       

