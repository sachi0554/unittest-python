

import unittest 
from email_extract import email_data_from_json


class Test_EmailExtract(unittest.TestCase):


    def test_process_get_email_key(self):  

        email_rec = email_data_from_json()

        self.assertGreater(len(email_rec) , 0)
        self.assertEqual('SREA' in email_rec , True)
        self.assertEqual('ICRReporting' in email_rec , True)
        self.assertEqual('MendixSummaries' in email_rec , True)
        self.assertEqual('cc_email' in email_rec , True)
        self.assertEqual('Shenney' in email_rec , True)
        self.assertEqual('MendixLog' in email_rec , True)

    def test_process_get_email_value(self):  

        email_rec = email_data_from_json()

        self.assertEqual(email_rec.get('SREA') is not None , True)
        self.assertEqual(email_rec.get('ICRReporting') is not None , True)
        self.assertEqual(email_rec.get('MendixSummaries') is not None , True)
        self.assertEqual(email_rec.get('cc_email') is not None , True)
        self.assertEqual(email_rec.get('Shenney') is not None , True)
        self.assertEqual(email_rec.get('MendixLog') is not None , True)