
import os
from unittest import TestCase, mock
import argparse
import tempfile
from datetime import date
import shutil

from  SEG.utils.SEGUtils import get_app_work_dir
import ScrubLinkedInData
from ScrubLinkedInDataSupport import ScrubLinkedInDataSupport, test_encoding, test_chinese_encoding, send_email

class TestScrubLinkedInData(TestCase):


    root_directory = tempfile.mkdtemp()
    os.makedirs(root_directory+"/archive")
    ts = date.today().strftime('%Y%m%d%H%M%S')
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    log_config_file = ''
    chinese_char_file= "test_chinese_char.csv"
    without_chinese_char_file= "test_without_chinese_char.csv"
    source_file_with_chinese_char=os.path.join(get_app_work_dir(), chinese_char_file)
    source_file_without_chinese_char= os.path.join(get_app_work_dir(), without_chinese_char_file)
    convert_source_file= f"test_convert_source{ts}.xlsx"
    converted_source_file_path=os.path.join(root_directory, convert_source_file)
    ready_file=os.path.join(root_directory, f"test_ready{ts}.xlsx")
    reject_file=os.path.join(root_directory, f"test_source{ts}.xlsx")
    archive_path=os.path.join(root_directory, "archive")



    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)

    

    def test_source_chinese_char_file_exist(self):
        
        self.assertTrue(os.path.exists(self.source_file_with_chinese_char))


    def test_source_without_chinese_char_file_exist(self):
        
        self.assertTrue(os.path.exists(self.source_file_without_chinese_char))
    
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                log_config_file='',
                sourceFile= source_file_with_chinese_char,
                convertedSourceFile=converted_source_file_path,
                readyFile=ready_file,
                rejectFile=reject_file,
                archivePath=archive_path,
                subject="test subject"
               ))
    def test_local_process_variable(self, args):
        param_variables, ret_code =ScrubLinkedInData.process_local_variables()

        self.assertEqual(ret_code , 0)


    def test_chinese_character_if_true(self):
        param_variables={}
        param_variables["sourceFile"]= self.source_file_with_chinese_char

        supp = ScrubLinkedInDataSupport(param_variables)

        ret = supp.test_for_chinese_characters()

        self.assertTrue(ret)
    

    def test_chinese_character_if_false(self):
        param_variables={}
        param_variables["sourceFile"]= self.source_file_without_chinese_char

        supp = ScrubLinkedInDataSupport(param_variables)

        ret = supp.test_for_chinese_characters()

        self.assertFalse(ret)

    def test_encoding_with_issue(self):

        text=  b'\xc3'

        ret = test_encoding(text)

        self.assertFalse(ret)

    def test_if_chinese_char_found(self):

        text=  u'\u4E00\u9FFF\uFF00'

        ret = test_chinese_encoding(text)

        self.assertFalse(ret)

    def test_if_chinese_char_not_found(self):

        text=  u'\xe8'

        ret = test_chinese_encoding(text)

        self.assertTrue(ret)


    def test_process_chinese_file(self):
        param_variables={}
        param_variables["sourceFile"]= self.source_file_with_chinese_char
        param_variables["convertedSourceFile"]= self.converted_source_file_path
        param_variables["readyFile"]= self.ready_file
        param_variables["rejectFile"]= self.reject_file
        param_variables["archivePath"]= self.archive_path
        param_variables["subject"]= "test subject "
        move_source_file_path = os.path.join(self.archive_path, self.chinese_char_file)
        move_convert_source_file_path = os.path.join(self.archive_path, self.convert_source_file)



        supp = ScrubLinkedInDataSupport(param_variables)
        supp.process_chinese_file()

        shutil.copy(move_source_file_path , get_app_work_dir())

        self.assertTrue(os.path.exists(move_convert_source_file_path))
        self.assertTrue(os.path.exists(self.ready_file))


    def test_process_file(self):
        param_variables={}
        param_variables["sourceFile"]= self.source_file_without_chinese_char
        convert_source= self.convert_source_file.split(".")[0]
        convert_source_file= convert_source + self.ts +".xlsx"
        param_variables["convertedSourceFile"]= os.path.join(self.root_directory , convert_source_file)
        param_variables["readyFile"]= self.ready_file
        param_variables["rejectFile"]= self.reject_file
        param_variables["archivePath"]= self.archive_path
        move_source_file_path = os.path.join(self.archive_path, self.without_chinese_char_file)
        move_convert_source_file_path = os.path.join(self.archive_path, self.convert_source_file)

 

        supp = ScrubLinkedInDataSupport(param_variables)
        supp.process_file()
   
        shutil.copy(move_source_file_path , get_app_work_dir())

        self.assertTrue(os.path.exists(move_convert_source_file_path))
        self.assertTrue(os.path.exists(self.ready_file))



    @mock.patch.object(ScrubLinkedInDataSupport,"process_chinese_file")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                log_config_file='',
                sourceFile= source_file_with_chinese_char,
                convertedSourceFile=converted_source_file_path,
                readyFile=ready_file,
                rejectFile=reject_file,
                archivePath=archive_path,
                subject="test subject"
               ))
    def test_workflow_with_chinese_char(self, args, mock_process_chinese_file):

        param_variables={}
        param_variables["sourceFile"]= self.source_file_with_chinese_char
        param_variables["subject"] = "email subject for test"

        mock_process_chinese_file.return_value = ""

        ret = ScrubLinkedInData.main()

        self.assertEqual(ret , 0)


    @mock.patch.object(ScrubLinkedInDataSupport,"process_file")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                log_config_file='',
                sourceFile= source_file_without_chinese_char,
                convertedSourceFile=converted_source_file_path,
                readyFile=ready_file,
                rejectFile=reject_file,
                archivePath=archive_path,
                subject="test subject"
               ))
    def test_workflow_without_chinese_char(self, args, mock_process_file):

        param_variables={}
        param_variables["sourceFile"]= self.source_file_with_chinese_char
        mock_process_file.return_value = ""

        ret = ScrubLinkedInData.main()

        self.assertEqual(ret , 0)






















