
import os
import shutil
import unittest
from unittest import mock
import argparse
import tempfile
from datetime import date
import logging

from SEG.utils.SEGUtils import  get_app_root_dir
import MasterProjectViewNotify
from MasterProjectViewNotifySupport import MasterProjectViewNotifySupport




class TestMasterProjectViewNotify(unittest.TestCase):
    root_directory = tempfile.mkdtemp()
    RUNMODE = os.environ.get("RUNMODE")
    ts = date.today().strftime('%Y%m%d%H%M%S')
    notification_file = os.path.join(root_directory, f"MasterProjectView_{ts}.xlsx")
    config_file = os.path.join(get_app_root_dir()+ "conf", f"MasterProjectViewNotify_{RUNMODE}.json")
    db_conn= mock.Mock()




    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)

    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                notificationFile=notification_file,  
                log_level="INFO",
                section_name="test",
                subject="test subject"
               ))
    def test_process_local_variables(self , mock_args):
        options = MasterProjectViewNotify.read_commandline_args()

        self.assertEqual(options.notificationFile, self.notification_file)

    def test_config_file_exist(self):
        
        self.assertTrue(os.path.exists(self.config_file))


    # def test_read_config_file_exist(self):

    #     config =MasterProjectViewNotify.read_config()

    #     self.assertEqual(config["section_name"], "FRMS_Test")



    def test_master_project_view_notify_support_constractor(self):
        MasterProjectViewNotifySupport(self.notification_file, self.db_conn)
        self.assertTrue(os.path.exists(self.notification_file))



    def test_populate_open(self):
        mock_data=[
("Project One",	0.00,	"01/10/2022",	"Analyst 1",	"Unassigned"  ,	"Sample Sourcer1"	,"NULL",	"Ongoing",	"Open",	"01/10/2022",	"Portfolio One",	1,	"3/3/22 - This is sample data for unit tests"	,"NULL",	"NULL"	,6	,"Ongoing"),
("Project Two",	0.00,	"02/07/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio Two"	,1	,"3/9 This is sample data for unit tests",	"This is sample data for unit tests",	"NULL",	2,	"Ongoing")]

        supp= MasterProjectViewNotifySupport(self.notification_file, self.db_conn)
        size_before = os.path.getsize(self.notification_file)
 
        supp.populate_open(mock_data)
        size_after = os.path.getsize(self.notification_file)


        self.assertGreater(size_after, size_before)

    def test_unassigned(self):
        mock_data=[
("Project One",	0.00,	"01/10/2022",	"Analyst 1",	"Unassigned"  ,	"Unassigned Sourcer1"	,"NULL",	"Pending",	"Unassigned",	"01/10/2022",	"Portfolio One",	1,	"3/3/22 - This is sample data for unit tests"	,"NULL",	"NULL"	,0	,"Awaiting Sourcing"),
("Project Two",	0.00,	"02/07/2022",	"Analyst 2",	"Unassigned",	"Unassigned Sourcer2",	"NULL",	"NULL",	"Unassigned",	"02/07/2022",	"Portfolio Two"	,1	,"3/9 This is sample data for unit tests",	"This is sample data for unit tests",	"NULL",	0,	"NULL")]

        supp= MasterProjectViewNotifySupport(self.notification_file, self.db_conn)
        size_before = os.path.getsize(self.notification_file)
 
        supp.populate_unassigned(mock_data)
        size_after = os.path.getsize(self.notification_file)


        self.assertGreater(size_after, size_before)
    

    @mock.patch("MasterProjectViewNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                notificationFile=notification_file,  
                log_level="INFO",
                section_name="",
                subject="test subject"
               ))
    def test_main_db_connection_failed(self, arg, mock_db_conn):
        mock_db_conn.return_value = ''
        ret_code = MasterProjectViewNotify.main()
        
        
        self.assertEqual(ret_code , -1)
    
    @mock.patch.object(MasterProjectViewNotifySupport,"scan_for_open_master_project_view_records")
    @mock.patch("MasterProjectViewNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                notificationFile=notification_file,  
                log_level="INFO",
                section_name="",
                subject="test subject"
               ))
    def test_main_scan_for_master_project_view_records_none(self, arg, mock_db_conn, mock_scan_for_open_master):
        mock_db_conn.return_value = self.db_conn
        mock_scan_for_open_master.return_value= []
        with self.assertRaises(SystemExit) as sye:
                MasterProjectViewNotify.main()

        
        self.assertEqual(sye.exception.code , 0)

    @mock.patch.object(MasterProjectViewNotifySupport,"scan_for_unassigned_master_project_view_records")
    @mock.patch.object(MasterProjectViewNotifySupport,"scan_for_open_master_project_view_records")
    @mock.patch("MasterProjectViewNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                notificationFile=notification_file,  
                log_level="INFO",
                section_name="",
                subject="test subject"
               ))
    def test_main_scan_for_unassigned_master_project_view_records_none(self, arg, mock_db_conn, mock_scan_for_open_master,mock_scan_for_unassigned_open_master):
        mock_data=[
("Project One",	0.00,	"01/10/2022",	"Analyst 1",	"Unassigned"  ,	"Sample Sourcer1"	,"NULL",	"Ongoing",	"Open",	"01/10/2022",	"Portfolio One",	1,	"3/3/22 - This is sample data for unit tests"	,"NULL",	"NULL"	,6	,"Ongoing"),
("Project Two",	0.00,	"02/07/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio Two"	,1	,"3/9 This is sample data for unit tests",	"This is sample data for unit tests",	"NULL",	2,	"Ongoing")]
        mock_db_conn.return_value = self.db_conn
        mock_scan_for_open_master.return_value= mock_data
        mock_scan_for_unassigned_open_master.return_value= []
        with self.assertRaises(SystemExit) as sye:
                MasterProjectViewNotify.main()

        
        self.assertEqual(sye.exception.code , 0)


    @mock.patch.object(MasterProjectViewNotifySupport,"scan_for_unassigned_master_project_view_records")
    @mock.patch.object(MasterProjectViewNotifySupport,"scan_for_open_master_project_view_records")
    @mock.patch("MasterProjectViewNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                notificationFile=notification_file,  
                log_level="INFO",
                section_name="",
                subject="test subject"
               ))
    def test_for_email_notify(self, arg, mock_db_conn, mock_scan_for_open_master,mock_scan_for_unassigned_open_master):
        mock_data_open=[
("Project One",	0.00,	"01/10/2022",	"Analyst 1",	"Unassigned"  ,	"Sample Sourcer1"	,"NULL",	"Ongoing",	"Open",	"01/10/2022",	"Portfolio One",	1,	"3/3/22 - This is sample data for unit tests"	,"NULL",	"NULL"	,6	,"Ongoing"),
("Project Two",	0.00,	"02/07/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio Two"	,1	,"3/9 This is sample data for unit tests",	"This is sample data for unit tests",	"NULL",	2,	"Ongoing")]
        mock_data_unassigned=[
("Project One",	0.00,	"01/10/2022",	"Analyst 1",	"Unassigned"  ,	"Unassigned Sourcer1"	,"NULL",	"Pending",	"Unassigned",	"01/10/2022",	"Portfolio One",	1,	"3/3/22 - This is sample data for unit tests"	,"NULL",	"NULL"	,0	,"Awaiting Sourcing"),
("Project Two",	0.00,	"02/07/2022",	"Analyst 2",	"Unassigned",	"Unassigned Sourcer2",	"NULL",	"NULL",	"Unassigned",	"02/07/2022",	"Portfolio Two"	,1	,"3/9 This is sample data for unit tests",	"This is sample data for unit tests",	"NULL",	0,	"NULL")]
        mock_db_conn.return_value = self.db_conn
        mock_scan_for_open_master.return_value= mock_data_open
        mock_scan_for_unassigned_open_master.return_value= mock_data_unassigned
        
        ret_code= MasterProjectViewNotify.main()

        
        self.assertEqual(ret_code, 0)

   
    def test_for_null_notification_file_email_call_failed(self):
        notification_file= ''
        subject = "email subject for test "
        ret_code= MasterProjectViewNotify.send_email(notification_file, subject)

        
        self.assertEqual(ret_code, -1)

 
        
      

    




        
