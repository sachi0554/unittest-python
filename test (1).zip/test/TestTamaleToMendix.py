import argparse
from unittest import TestCase, mock
from urllib import  response
import TamaleToMendix
from TamaleToMendixSupport import TamaleToMendixSupport

class TestTamaleToMendix(TestCase):


    sqlSectionName=''
    db_conn= mock.Mock()
    log_level="INFO"
    


    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                ini_file='',
                section_name= sqlSectionName,
                log_level=log_level,
                subject="test subject"
               ))
    def test_local_process_variable(self, args):
        param= TamaleToMendix.read_commandline_args()



        self.assertEqual(param.log_level, self.log_level)
        self.assertEqual(param.section_name, '')


   
    def test_read_config_file(self):
        config= TamaleToMendix.read_config_file()

        self.assertTrue("Mendix_REST_URL" in config)
        self.assertTrue("Tamale_URL" in config)
        self.assertTrue("sender_email" in config)
        self.assertTrue("recipient_email" in config)
        self.assertTrue("cc_email" in config)


    @mock.patch.object(TamaleToMendixSupport,"get_data")
    def test_read_tamale_data(self, mock_get_data):
        mock_data =[("5c108ebeb5824fdf9e68f7a8a6bea3de",	"Sourcing Request",	"TEST - ENTITY (Project 2222)"	,"TEST - ENTITY (Project 2222)",	"Jim Hagy",	"big picture",	"SAMPLE",	"Internal Sourcing",	"NULL",	"TEST NAME",	"10/02/2020")]

        mock_get_data.return_value= mock_data

        config= TamaleToMendix.read_config_file()
        supp =TamaleToMendixSupport(self.db_conn)

        payload =TamaleToMendix.read_tamale_data(mock_data, config["Tamale_URL"])

        convert_dict= TamaleToMendix.convert_dict(payload)

        self.assertEqual(convert_dict["NoteID"], "5c108ebeb5824fdf9e68f7a8a6bea3de")
        self.assertEqual(convert_dict["NoteURL"], config["Tamale_URL"]+"5c108ebeb5824fdf9e68f7a8a6bea3de")
        self.assertEqual(convert_dict["NoteType"], "Sourcing Request")
        self.assertEqual(convert_dict["EntityLongName"], "TEST - ENTITY (Project 2222)")
        self.assertEqual(convert_dict["EntityShortName"], "TEST - ENTITY (Project 2222)")
        self.assertEqual(convert_dict["Source"], "Jim Hagy")
        self.assertEqual(convert_dict["Subject"], "big picture")
        self.assertEqual(convert_dict["Portfolio"], "SAMPLE")
        self.assertEqual(convert_dict["SourcingType"], "Internal Sourcing")
        self.assertEqual(convert_dict["PortfoliosHotlist"], "NULL")
        self.assertEqual(convert_dict["SubmitterName"], "TEST NAME")
        self.assertEqual(convert_dict["NoteSubmissionDate"], "10/02/2020")


    @mock.patch.object(TamaleToMendixSupport,"set_is_processed_flag")
    @mock.patch.object(TamaleToMendixSupport,"get_data")
    def test_set_flag(self, mock_get_data, mock_set_is_processed_flag):
        mock_data =[("5c108ebeb5824fdf9e68f7a8a6bea3de",	"Sourcing Request",	"TEST - ENTITY (Project 2222)"	,"TEST - ENTITY (Project 2222)",	"Jim Hagy",	"big picture",	"SAMPLE",	"Internal Sourcing",	"NULL",	"TEST NAME",	"10/02/2020")]

        mock_get_data.return_value= mock_data
        mock_set_is_processed_flag.return_value= 0
        mock_response=response
        mock_response.status_code= 200

        config= TamaleToMendix.read_config_file()
        supp =TamaleToMendixSupport(self.db_conn)

        payload =TamaleToMendix.read_tamale_data(mock_data, config["Tamale_URL"])
        ret = TamaleToMendix.set_flag(supp, payload, mock_response)

        self.assertEqual(ret, 0)

    @mock.patch.object(TamaleToMendixSupport,"set_is_processed_flag")
    @mock.patch.object(TamaleToMendixSupport,"get_data")
    def test_set_flag_on_failed(self, mock_get_data, mock_set_is_processed_flag):
        mock_data =[("5c108ebeb5824fdf9e68f7a8a6bea3de",	"Sourcing Request",	"TEST - ENTITY (Project 2222)"	,"TEST - ENTITY (Project 2222)",	"Jim Hagy",	"big picture",	"SAMPLE",	"Internal Sourcing",	"NULL",	"TEST NAME",	"10/02/2020")]

        mock_get_data.return_value= mock_data
        mock_set_is_processed_flag.return_value= 0
        mock_response=response
        mock_response.status_code= 500
        mock_response.text= "Error on server"

        config= TamaleToMendix.read_config_file()
        supp =TamaleToMendixSupport(self.db_conn)

        payload =TamaleToMendix.read_tamale_data(mock_data, config["Tamale_URL"])
        ret = TamaleToMendix.set_flag(supp, payload, mock_response)

        self.assertEqual(ret, -1)


    @mock.patch.object(TamaleToMendixSupport,"set_is_processed_flag")
    @mock.patch.object(TamaleToMendixSupport,"get_data")
    @mock.patch("TamaleToMendix.call_rest_service")
    @mock.patch("TamaleToMendix.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                ini_file='',
                section_name= sqlSectionName,
                log_level=log_level,
                subject="test subject"
               ))
    def test_workflow_with_success(self,args, mock_db, mock_rest_service, mock_get_data, mock_set_is_processed_flag):
        mock_data =[[("5c108ebeb5824fdf9e68f7a8a6bea3de",	"Sourcing Request",	"TEST - ENTITY (Project 2222)"	,"TEST - ENTITY (Project 2222)",	"Jim Hagy",	"big picture",	"SAMPLE",	"Internal Sourcing",	"NULL",	"TEST NAME",	"10/02/2020")],[]]

        
        mock_db.return_value= self.db_conn
        mock_get_data.side_effect= mock_data
        mock_set_is_processed_flag.return_value= 0
        mock_response=response
        mock_response.status_code= 200
        mock_rest_service.return_value= mock_response
       


        ret= TamaleToMendix.main()
        
        self.assertEqual(ret, 0)


    @mock.patch.object(TamaleToMendixSupport,"set_is_processed_flag")
    @mock.patch.object(TamaleToMendixSupport,"get_data")
    @mock.patch("TamaleToMendix.send_email")
    @mock.patch("TamaleToMendix.call_rest_service")
    @mock.patch("TamaleToMendix.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                ini_file='',
                section_name= sqlSectionName,
                log_level=log_level,
                subject="test subject"
               ))
    def test_workflow_with_failed_notification(self,args, mock_db, mock_rest_service, mock_send_email, mock_get_data, mock_set_is_processed_flag):
        mock_data =[[("5c108ebeb5824fdf9e68f7a8a6bea3de",	"Sourcing Request",	"TEST - ENTITY (Project 2222)"	,"TEST - ENTITY (Project 2222)",	"Jim Hagy",	"big picture",	"SAMPLE",	"Internal Sourcing",	"NULL",	"TEST NAME",	"10/02/2020")],[]]

        mock_get_data.side_effect= mock_data
        mock_db.return_value=self.db_conn

        mock_set_is_processed_flag.return_value= 0
        mock_response=response
        mock_response.status_code= 500
        mock_response.text="server error"
        mock_rest_service.return_value= mock_response

        TamaleToMendix.main()
        
        self.assertEqual(mock_send_email.call_count, 1)

