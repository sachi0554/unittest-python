
import os
import shutil
import unittest
from unittest import mock
import tempfile
import argparse
from datetime import date
from ProjectsAwaitingReportsNotifySupport import ProjectsAwaitingReportsNotifySupport
from SEG.utils.SEGUtils import  get_app_root_dir
import ProjectsAwaitingReportsNotify



class TestProjectsAwaitingReportsNotify(unittest.TestCase):
    root_directory = tempfile.mkdtemp()
    ts = date.today().strftime('%Y%m%d%H%M%S')
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    notificationFile = os.path.join(root_directory, f"ProjectsAwaitingReports_{ts}.xlsx")
    log_config_file = os.environ.get("PY_LOG_CONFIG")
    sqlSectionName = ""
    db_conn= mock.Mock()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)

    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug=True,jams_id=jams_id,
                notificationFile=notificationFile  ,
                sqlSectionName=sqlSectionName,
                log_config_file = log_config_file,
                subject="test subject"
               ))
    def test_process_local_variables(self , mock_args):

        param_variables, ret_code = ProjectsAwaitingReportsNotify.process_local_variables()

        self.assertEqual(ret_code, 0)
        self.assertEqual(param_variables["notificationFile"], self.notificationFile)
        self.assertEqual(param_variables["sqlSectionName"], self.sqlSectionName)
        self.assertEqual(param_variables["debug"], True)
        self.assertEqual(param_variables["log_config_file"], self.log_config_file) 


    def test_project_awaiting_notify_support_constractor(self):

        param_variables={}
        param_variables["notificationFile"]= self.notificationFile
        ProjectsAwaitingReportsNotifySupport(param_variables, self.db_conn)
        self.assertTrue(os.path.exists(self.notificationFile))   


    def test_populate_open(self):
        mock_data=[
("Project One",	0.00,	"11/12/2020",	"Analyst 1",	"NULL"  ,	"Sample Sourcer1"	,"NULL",	"Complete",	"Closed_Awaiting_Report",	"11/12/2020",	"Portfolio One",	2,	"This is sample data for unit tests"	,"NULL",	"NULL"	,"Writing Report"),
("Project Two",	0.00,	"04/14/2020",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Complete",	"Closed_Awaiting_Report",	"04/14/2020",	"Portfolio Two"	,1	,"This is sample data for unit tests",	"NULL",	"This is sample data for unit tests",	"Complete")]


        param_variables={}
        param_variables["notificationFile"]= self.notificationFile
        supp= ProjectsAwaitingReportsNotifySupport(param_variables, self.db_conn)
        size_before = os.path.getsize(self.notificationFile)
 
        supp.populate(mock_data)
        size_after = os.path.getsize(self.notificationFile)

        self.assertGreater(size_after, size_before)   



    @mock.patch("ProjectsAwaitingReportsNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug=True,jams_id=jams_id,
                notificationFile=notificationFile  ,
                sqlSectionName=sqlSectionName,
                log_config_file = log_config_file,
                subject="test subject"
               ))
    def test_main_db_connection_failed(self, arg, mock_db_conn):
        mock_db_conn.return_value = -1 , self.db_conn

        with self.assertRaises(SystemExit) as sye:
                ProjectsAwaitingReportsNotify.main()

        self.assertEqual(sye.exception.code , -1)                 


    @mock.patch.object(ProjectsAwaitingReportsNotifySupport,"scan_for_projects_awaiting_reports_records")
    @mock.patch("ProjectsAwaitingReportsNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug=True,jams_id=jams_id,
                notificationFile=notificationFile  ,
                sqlSectionName=sqlSectionName,
                log_config_file = log_config_file,
                subject="test subject"
               ))
    def test_main_db_connection_send_email(self, arg, mock_db_conn,mock_scan_for_project_awaiting):
        mock_data=[
("Project One",	0.00,	"11/12/2020",	"Analyst 1",	"NULL"  ,	"Sample Sourcer1"	,"NULL",	"Complete",	"Closed_Awaiting_Report",	"11/12/2020",	"Portfolio One",	2,	"This is sample data for unit tests"	,"NULL",	"NULL"	,"Writing Report"),
("Project Two",	0.00,	"04/14/2020",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Complete",	"Closed_Awaiting_Report",	"04/14/2020",	"Portfolio Two"	,1	,"This is sample data for unit tests",	"NULL",	"This is sample data for unit tests",	"Complete")]

        mock_db_conn.return_value = 0 , self.db_conn
        mock_scan_for_project_awaiting.return_value= mock_data

        ret_code = ProjectsAwaitingReportsNotify.main()

        self.assertEqual(ret_code , 0)    


    @mock.patch.object(ProjectsAwaitingReportsNotifySupport,"scan_for_projects_awaiting_reports_records")
    @mock.patch("ProjectsAwaitingReportsNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug=True,jams_id=jams_id,
                notificationFile=notificationFile  ,
                sqlSectionName=sqlSectionName,
                log_config_file = log_config_file,
                subject="test subject"
               ))
    def test_scan_for_project_awaiting_report_record(self, arg, mock_db_conn,mock_scan_for_project_awaiting):

        mock_db_conn.return_value = 0 , self.db_conn
        mock_scan_for_project_awaiting.return_value= []
        
        with self.assertRaises(SystemExit) as sye:
                ProjectsAwaitingReportsNotify.main()

        self.assertEqual(sye.exception.code , 0)  