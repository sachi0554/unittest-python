
from email.policy import default
import imp


import os
import shutil
from unittest import TestCase, mock
import argparse
import tempfile
from datetime import date
import ProjectSummariesNotify
from ProjectSummariesNotifySupport import ProjectSummariesNotifySupport



class TestProjectSummariesNotify(TestCase):


    root_directory = tempfile.mkdtemp()
    ts = date.today().strftime('%Y%m%d%H%M%S')
    notificationFile = os.path.join(root_directory, f"MasterProjectView_{ts}.xlsx")
    jams_id="test_"+date.today().strftime('%Y%m%d%H%M%S')
    sqlSectionName=''
    db_conn= mock.Mock()
    log_config_file=os.environ.get("PY_LOG_CONFIG")



    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root_directory)


    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                sqlSectionName= sqlSectionName,
                notificationFile=notificationFile,
                log_config_file=log_config_file,
                subject="test subject"
               ))
    def test_local_process_variable(self, args):
        param_variables, ret_code =ProjectSummariesNotify.process_local_variables()

        self.assertEqual(ret_code , 0)


    def test_project_summaries_notify_support_constractor(self):
        param_variables={}
        param_variables["notificationFile"] = self.notificationFile
        ProjectSummariesNotifySupport(param_variables, self.db_conn)


        self.assertTrue(os.path.exists(self.notificationFile))


    def test_populate_summary_by_sourcer(self):
        mock_data=[
("Project One",	0.00,	"12/09/2021",	"Analyst 1",	"Test QFA"  ,	"Sample Sourcer1"	,"NULL",	"Complete",	"Open",	"12/09/2021",	"Portfolio One",	6,	"This is sample data for unit tests"	,"NULL",	"NULL"	,9	,"Writing Report"),
("Project Two",	0.00,	"02/11/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio One"	,1	,"This is sample data for unit tests",	"NULL",	"NULL",	4,	"Ongoing")]
        

        param_variables={}
        param_variables["notificationFile"] = self.notificationFile
        supp= ProjectSummariesNotifySupport(param_variables, self.db_conn)
        size_before = os.path.getsize(self.notificationFile)
 
        supp.populate_summary_by_sourcer(mock_data)
        size_after = os.path.getsize(self.notificationFile)


        self.assertGreater(size_after, size_before)


    def test_populate_summary_by_qfa(self):
        mock_data=[
("Project One",	0.00,	"12/09/2021",	"Analyst 1",	"Test QFA"  ,	"Sample Sourcer1"	,"NULL",	"Pending",	"Open",	"12/09/2021",	"Portfolio One",	6,	"3/3/22 - This is sample data for unit tests"	,"This is sample data for unit tests",	"NULL"	,0	,"Ongoing"),
("Project Two",	0.00,	"02/11/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio One"	,1	,"This is sample data for unit tests",	"NULL",	"NULL",	4,	"Stage1")]
        

        param_variables={}
        param_variables["notificationFile"] = self.notificationFile
        supp= ProjectSummariesNotifySupport(param_variables, self.db_conn)
        size_before = os.path.getsize(self.notificationFile)
 
        supp.populate_summary_by_sourcer(mock_data)
        size_after = os.path.getsize(self.notificationFile)


        self.assertGreater(size_after, size_before)


    @mock.patch("ProjectSummariesNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                sqlSectionName= sqlSectionName,
                notificationFile=notificationFile,
                log_config_file=log_config_file,
                subject="test subject"
               ))
    def test_main_db_connection_failed(self, arg, mock_db_conn):
        mock_db_conn.return_value = -1,''

        with self.assertRaises(SystemExit) as sye:
                ProjectSummariesNotify.main()

        
        
        self.assertEqual(sye.exception.code , -1)


    @mock.patch.object(ProjectSummariesNotifySupport,"scan_for_project_summary_by_sourcer_records")
    @mock.patch("ProjectSummariesNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                sqlSectionName= sqlSectionName,
                notificationFile=notificationFile,
                log_config_file=log_config_file,
                subject="test subject"
               ))
    def test_scan_for_project_summary_by_sourcer_records_none(self, arg, mock_db_conn, mock_scan_for_sum):
        mock_db_conn.return_value = 0 , self.db_conn
        mock_scan_for_sum.return_value= []
        with self.assertRaises(SystemExit) as sye:
                ProjectSummariesNotify.main()

        
        self.assertEqual(sye.exception.code , 0)

    @mock.patch.object(ProjectSummariesNotifySupport,"scan_for_project_summary_by_qfa_records")
    @mock.patch.object(ProjectSummariesNotifySupport,"scan_for_project_summary_by_sourcer_records")
    @mock.patch("ProjectSummariesNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                sqlSectionName= sqlSectionName,
                notificationFile=notificationFile,
                log_config_file=log_config_file,
                subject="test subject"
               ))
    def test_scan_for_project_summary_by_qfa_records_none(self, arg, mock_db_conn, mock_scan_for_sum, mock_scan_for_sum_qfa):
        mock_data=[
("Project One",	0.00,	"12/09/2021",	"Analyst 1",	"Test QFA"  ,	"Sample Sourcer1"	,"NULL",	"Complete",	"Open",	"12/09/2021",	"Portfolio One",	6,	"This is sample data for unit tests"	,"NULL",	"NULL"	,9	,"Writing Report"),
("Project Two",	0.00,	"02/11/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio One"	,1	,"This is sample data for unit tests",	"NULL",	"NULL",	4,	"Ongoing")]
        mock_db_conn.return_value = 0 , self.db_conn
        mock_scan_for_sum.return_value= mock_data
        mock_scan_for_sum_qfa.return_value= []
        with self.assertRaises(SystemExit) as sye:
                ProjectSummariesNotify.main()

        
        self.assertEqual(sye.exception.code , 0)

    
    @mock.patch("ProjectSummariesNotify.send_email")
    @mock.patch.object(ProjectSummariesNotifySupport,"scan_for_project_summary_by_qfa_records")
    @mock.patch.object(ProjectSummariesNotifySupport,"scan_for_project_summary_by_sourcer_records")
    @mock.patch("ProjectSummariesNotify.get_db_conn")
    @mock.patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                debug= True,
                jams_id=jams_id,
                sqlSectionName= sqlSectionName,
                notificationFile=notificationFile,
                log_config_file=log_config_file,
                subject="test subject"
               ))
    def test_send_email(self, arg, mock_db_conn, mock_scan_for_sum, mock_scan_for_sum_qfa, mock_send_email):
        mock_data_source=[
("Project One",	0.00,	"12/09/2021",	"Analyst 1",	"Test QFA"  ,	"Sample Sourcer1"	,"NULL",	"Complete",	"Open",	"12/09/2021",	"Portfolio One",	6,	"This is sample data for unit tests"	,"NULL",	"NULL"	,9	,"Writing Report"),
("Project Two",	0.00,	"02/11/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio One"	,1	,"This is sample data for unit tests",	"NULL",	"NULL",	4,	"Ongoing")]
        mock_data_qfa=[
("Project One",	0.00,	"12/09/2021",	"Analyst 1",	"Test QFA"  ,	"Sample Sourcer1"	,"NULL",	"Pending",	"Open",	"12/09/2021",	"Portfolio One",	6,	"3/3/22 - This is sample data for unit tests"	,"This is sample data for unit tests",	"NULL"	,0	,"Ongoing"),
("Project Two",	0.00,	"02/11/2022",	"Analyst 2",	"Test QFA",	"Sample Sourcer2",	"NULL",	"Ongoing",	"Open",	"02/07/2022",	"Portfolio One"	,1	,"This is sample data for unit tests",	"NULL",	"NULL",	4,	"Stage1")]
        
        mock_db_conn.return_value = 0 , self.db_conn
        mock_scan_for_sum.return_value= mock_data_source
        mock_scan_for_sum_qfa.return_value= mock_data_qfa
        
        ProjectSummariesNotify.main()

        

        
        self.assertEqual(mock_send_email.call_count , 1)


